#pragma once

namespace Robot {

class DistanceSensor {
public: 


DistanceSensor();

int get_distance();

};
}