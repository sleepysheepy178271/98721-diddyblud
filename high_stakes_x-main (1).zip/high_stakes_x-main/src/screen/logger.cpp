#include "screen/logger.h"

#include "main.h" // IWYU pragma: export
#include "robot/auton.h"

using namespace Robot;

logger_screen::logger_screen() {}

void logger_screen::log() {}